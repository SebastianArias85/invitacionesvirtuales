<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>invitaciones virtuales</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<link href="estilo.css" rel="stylesheet" type="text/css">
<link href="style-invit.css" rel="stylesheet" type="text/css">
    <link rel="apple-touch-icon" sizes="152x152" href="../apple-touch-icon.png">
<link rel="icon" type="image/png" sizes="32x32" href="../favicon-32x32.png">
<link rel="icon" type="image/png" sizes="16x16" href="../favicon-16x16.png">
<link rel="manifest" href="../site.webmanifest">
<link rel="mask-icon" href="../safari-pinned-tab.svg" color="#5bbad5">
<meta name="msapplication-TileColor" content="#da532c">
<meta name="theme-color" content="#ffffff">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,600|Quicksand:700" rel="stylesheet"> 
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.13.1/themes/base/jquery-ui.css">
</head>

<body>


<div class="w3-content" style="margin-top:40px; padding:20px;" > <!-- class="block fondo-amarillo"  -->
<img src="../images/logo-glow.png" alt="invinet" width="280px" class="w3-image w3-margin-bottom" />


<p style="font-size:18px;">Realizamos Invitaciones Virtuales para particulares y para salones de fiestas. Las mismas contienen una portada que puede ser la foto del o de los agasajados, cuenta regresiva, galeria de fotos, mapa con la ubicación y sistema ineractivo para llamar al salón, agendar el evento y confirmar la asistencia.</p>





<div class="w3-row">
  <div class="w3-third w3-container">
    <a href="https://api.whatsapp.com/send?phone=5491136802702" target="_blank" class="w3-btn w3-black  w3-round-xlarge" style="white-space: normal; margin:20px 10px">Consultar por invitación particular</a>
  </div>
  <div class="w3-third w3-container">
    <a href="https://api.whatsapp.com/send?phone=5491136802578" target="_blank"  class="w3-btn  w3-black  w3-round-xlarge" style="white-space: normal; margin:20px 10px" >Consultar por invitaciones para salones de fiestas</a>
  </div>
  <div class="w3-third w3-container">
 <a href="https://invitacionesvirtuales.net" target="_blank"  class="w3-btn  w3-black  w3-round-xlarge" style="white-space: normal; margin:20px 10px">Visitá nuestro website</a>
  </div>
</div>

</div>


<div class="pie" style="margin-top:200px; background-color:#454649; padding:20px;">
  <strong style="color:#CCCCCC; font-size:14px;">invitaciones virtuales<sup>&reg;</sup></strong> <br>
<a href="https://www.invitacionesvirtuales.net/" target="_blank" style="color:#CCCCCC; font-size:14px;">www.invitacionesvirtuales.net</a>
</div>


</body>
</html>
